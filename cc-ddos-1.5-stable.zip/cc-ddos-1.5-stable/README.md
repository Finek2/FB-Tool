# cc-ddos
Một tập lệnh Python để DDOS một trang web bằng nhiều phương pháp HTTP Flood, một trang web bình thường chỉ cần 5s để sập hoàn toàn!
# Cách Dùng:

Tập lệnh này có thể hoạt động cả trên Windows, Linux Core lẫn Android (Termux), dưới đây là hướng dẫn:

Sử dụng phương pháp dưới đây sẽ chạy tập lệnh với cài đặt được cài trước tự động và sử dụng toàn bộ tài nguyên mạng để mang lại sức tấn công lớn nhất. Sử dụng script thủ công để có thể tuỳ chỉnh tấn công! 

Test (01/09/2022):
![image](https://user-images.githubusercontent.com/59746573/187913844-ff23d6f2-e4fb-4ad5-8f6b-1b73ab1f2aa6.png)
![image](https://user-images.githubusercontent.com/59746573/187913864-dd72e3ff-70ad-444f-a051-76e6dc659f97.png)


Windows:

```

> install.bat
> start.bat

```

Termux/Linux Core

```
Đã dùng CLI thì cần gì hướng dẫn đúng không =)) Gà quá thì mở tệp .bat lên mà đọc =))
```

# Important!!!

This script is for educational purposes only. I am not responsible for the damage you cause while using this script!

```

Based on CC-attack by Leeon123

```

